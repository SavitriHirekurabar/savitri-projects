@echo off
cls
echo ================================================================================
echo                    STARTING ML-POWERED DYNAMIC PRICING SYSTEM
echo ================================================================================
echo.
echo Starting Flask Backend Server (Fixed Version)...
echo.

cd /d "%~dp0"

start "Flask ML Server" cmd /c "python fixed_app.py"

echo.
echo Waiting for server to start...
timeout /t 3 /nobreak >nul

echo.
echo Opening ML Prediction Interface in your browser...
echo.
echo ================================================================================
echo 
echo ✅ Backend: Flask API running at http://localhost:5000
echo ✅ Frontend: ML Prediction Form opening now
echo.
echo URLs to try:
echo   • http://localhost:5000/
echo   • http://localhost:5000/ml_prediction_form.html
echo   • http://localhost:5000/api/model-info
echo.
echo Press Ctrl+C in the Flask window to stop the server
echo ================================================================================
echo.

REM Try multiple URLs to ensure it works
start http://localhost:5000/
timeout /t 2 /nobreak >nul
start http://localhost:5000/ml_prediction_form.html

pause
