"""
Price Prediction API
This script provides functions to predict prices using the trained model
"""

import joblib
import pandas as pd
import numpy as np
import json


class PricePredictor:
    def __init__(self, model_path='pricing_model.pkl'):
        """Initialize the predictor with trained model"""
        try:
            self.model = joblib.load(model_path)
            with open('model_metadata.json', 'r') as f:
                self.metadata = json.load(f)
            self.feature_columns = self.metadata['feature_columns']
            print("✓ Model loaded successfully")
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = None
            self.feature_columns = None
    
    def encode_product(self, product_data):
        """
        Encode categorical variables in product data
        
        Parameters:
        -----------
        product_data : dict with raw product information
        
        Returns:
        --------
        dict : Product data with encoded values
        """
        encoded = product_data.copy()
        
        # Brand encoding
        brand_mapping = {'BrandA': 0, 'BrandB': 1, 'BrandC': 2, 'BrandD': 3}
        if 'brand' in encoded:
            encoded['brand_encoded'] = brand_mapping.get(encoded['brand'], 0)
        
        # Category encoding
        category_mapping = {'Electronics': 0, 'Home': 1, 'Beauty': 2, 'Clothing': 3}
        if 'product_category' in encoded:
            encoded['category_encoded'] = category_mapping.get(encoded['product_category'], 0)
        
        # Promotion type encoding
        promotion_mapping = {'Sale': 0, 'Clearance': 1, 'Festival': 2}
        if 'promotion_type' in encoded:
            encoded['promotion_encoded'] = promotion_mapping.get(encoded['promotion_type'], 0)
        
        # Season encoding
        season_mapping = {'Summer': 0, 'Winter': 1, 'Monsoon': 2, 'Festival': 3}
        if 'season' in encoded:
            encoded['season_encoded'] = season_mapping.get(encoded['season'], 0)
        
        return encoded
    
    def predict(self, product_data):
        """
        Predict optimal price for a product
        
        Parameters:
        -----------
        product_data : dict containing product information
            Required fields:
            - base_price
            - competitor_price
            - cost_price
            - stock_quantity
            - daily_views
            - daily_sales
            - add_to_cart_count
            - customer_rating
            - discount_percentage
            - advertising_spend
            - brand (BrandA, BrandB, BrandC, BrandD)
            - product_category (Electronics, Home, Beauty, Clothing)
            - promotion_type (Sale, Clearance, Festival)
            - season (Summer, Winter, Monsoon, Festival)
            - day_of_week (0-6)
            - demand_index (1-10)
            - price_elasticity (0-2)
        
        Returns:
        --------
        dict : Prediction result with price and confidence
        """
        if self.model is None:
            return {"error": "Model not loaded", "predicted_price": None}
        
        # Encode categorical variables
        encoded_data = self.encode_product(product_data)
        
        # Create feature vector
        features = []
        for col in self.feature_columns:
            if col in encoded_data:
                features.append(encoded_data[col])
            else:
                return {
                    "error": f"Missing feature: {col}",
                    "predicted_price": None
                }
        
        # Reshape for prediction
        features_array = np.array(features).reshape(1, -1)
        
        # Make prediction
        predicted_price = self.model.predict(features_array)[0]
        
        # Calculate confidence based on R² score
        r2_score = self.metadata['metrics']['test_r2']
        confidence = min(1.0, max(0.0, r2_score))
        
        # Ensure non-negative price
        final_price = max(0, predicted_price)
        
        return {
            "predicted_price": round(final_price, 2),
            "confidence": round(confidence * 100, 2),
            "model_r2_score": round(r2_score * 100, 2),
            "currency": "USD"
        }
    
    def predict_bulk(self, products_list):
        """
        Predict prices for multiple products
        
        Parameters:
        -----------
        products_list : list of dicts, each containing product information
        
        Returns:
        --------
        list : List of prediction results
        """
        results = []
        for product in products_list:
            result = self.predict(product)
            result.update(product)
            results.append(result)
        return results


def demo_prediction():
    """Demonstrate price prediction with sample products"""
    print("\n" + "="*60)
    print("PRICE PREDICTION DEMO")
    print("="*60)
    
    predictor = PricePredictor()
    
    if predictor.model is None:
        print("Cannot run demo - model not available")
        return
    
    # Sample products
    sample_products = [
        {
            "product_name": "Premium Headphones",
            "base_price": 299.99,
            "competitor_price": 319.99,
            "cost_price": 180.00,
            "stock_quantity": 150,
            "daily_views": 2500,
            "daily_sales": 85,
            "add_to_cart_count": 120,
            "customer_rating": 4.6,
            "discount_percentage": 15,
            "advertising_spend": 1800.0,
            "brand": "BrandA",
            "product_category": "Electronics",
            "promotion_type": "Sale",
            "season": "Summer",
            "day_of_week": 5,
            "demand_index": 8,
            "price_elasticity": 1.6
        },
        {
            "product_name": "Luxury Skincare Set",
            "base_price": 149.99,
            "competitor_price": 159.99,
            "cost_price": 75.00,
            "stock_quantity": 300,
            "daily_views": 1800,
            "daily_sales": 62,
            "add_to_cart_count": 95,
            "customer_rating": 4.8,
            "discount_percentage": 20,
            "advertising_spend": 2200.0,
            "brand": "BrandB",
            "product_category": "Beauty",
            "promotion_type": "Festival",
            "season": "Winter",
            "day_of_week": 6,
            "demand_index": 9,
            "price_elasticity": 1.8
        },
        {
            "product_name": "Smart Home Device",
            "base_price": 199.99,
            "competitor_price": 189.99,
            "cost_price": 120.00,
            "stock_quantity": 200,
            "daily_views": 3200,
            "daily_sales": 110,
            "add_to_cart_count": 165,
            "customer_rating": 4.5,
            "discount_percentage": 10,
            "advertising_spend": 2500.0,
            "brand": "BrandC",
            "product_category": "Electronics",
            "promotion_type": "Clearance",
            "season": "Monsoon",
            "day_of_week": 3,
            "demand_index": 7,
            "price_elasticity": 1.4
        }
    ]
    
    print("\nRunning predictions for sample products...\n")
    
    for i, product in enumerate(sample_products, 1):
        result = predictor.predict(product)
        
        print(f"{i}. {product['product_name']}")
        print(f"   Base Price: ${product['base_price']}")
        print(f"   Category: {product['product_category']} | Brand: {product['brand']}")
        print(f"   Promotion: {product['promotion_type']} | Season: {product['season']}")
        
        if 'error' in result:
            print(f"   ❌ Error: {result['error']}")
        else:
            print(f"   💰 Predicted Optimal Price: ${result['predicted_price']}")
            print(f"   📊 Confidence: {result['confidence']}%")
            print(f"   🎯 Model Accuracy: {result['model_r2_score']}%")
            
            # Calculate price adjustment
            adjustment = ((result['predicted_price'] - product['base_price']) / product['base_price']) * 100
            if adjustment > 0:
                print(f"   📈 Recommendation: Increase price by {abs(adjustment):.1f}%")
            elif adjustment < 0:
                print(f"   📉 Recommendation: Decrease price by {abs(adjustment):.1f}%")
            else:
                print(f"   ➡️ Recommendation: Keep current price")
        
        print()
    
    print("="*60)
    print("Demo completed!")


if __name__ == "__main__":
    demo_prediction()
