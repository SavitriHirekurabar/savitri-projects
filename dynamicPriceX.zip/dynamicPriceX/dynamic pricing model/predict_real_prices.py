"""
Real Dataset Price Predictor
This script predicts optimal prices for products from your actual dataset
"""

import pandas as pd
import numpy as np
from predict_price import PricePredictor


def predict_from_dataset(csv_file='marketing_product_dataset_500_rows.csv', num_samples=10):
    """
    Load actual products from dataset and predict their optimal prices
    
    Parameters:
    -----------
    csv_file : str
        Path to the CSV file
    num_samples : int
        Number of products to predict (default: 10)
    """
    print("="*80)
    print("REAL DATASET PRICE PREDICTION")
    print("Using Linear Regression Model on Actual Products")
    print("="*80)
    
    # Load the dataset
    df = pd.read_csv(csv_file)
    
    # Initialize predictor
    predictor = PricePredictor()
    
    if predictor.model is None:
        print("❌ Error: Could not load the trained model!")
        print("   Please run: python pricing_model.py")
        return
    
    print(f"\nDataset loaded: {len(df)} products")
    print(f"Showing predictions for {num_samples} sample products\n")
    
    # Select random samples
    samples = df.sample(n=min(num_samples, len(df)), random_state=42)
    
    results = []
    
    for idx, row in samples.iterrows():
        print("-"*80)
        
        # Prepare product data
        product_data = {
            'base_price': row['base_price'],
            'competitor_price': row['competitor_price'],
            'cost_price': row['cost_price'],
            'stock_quantity': row['stock_quantity'],
            'daily_views': row['daily_views'],
            'daily_sales': row['daily_sales'],
            'add_to_cart_count': row['add_to_cart_count'],
            'customer_rating': row['customer_rating'],
            'discount_percentage': row['discount_percentage'],
            'advertising_spend': row['advertising_spend'],
            'brand': row['brand'],
            'product_category': row['product_category'],
            'promotion_type': row['promotion_type'],
            'season': row['season'],
            'day_of_week': row['day_of_week'],
            'demand_index': row['demand_index'],
            'price_elasticity': row['price_elasticity']
        }
        
        # Make prediction
        result = predictor.predict(product_data)
        
        # Display results
        print(f"Product ID: {row['product_id']}")
        print(f"Category: {row['product_category']} | Brand: {row['brand']}")
        print(f"Base Price: ${row['base_price']:.2f}")
        print(f"Current Final Price: ${row['final_price']:.2f}")
        
        if 'error' in result:
            print(f"❌ Error: {result['error']}")
        else:
            predicted_price = result['predicted_price']
            actual_price = row['final_price']
            
            print(f"💰 ML Predicted Optimal Price: ${predicted_price:.2f}")
            print(f"📊 Model Confidence: {result['confidence']}%")
            
            # Calculate difference
            difference = predicted_price - actual_price
            diff_percent = (difference / actual_price) * 100
            
            print(f"\n📈 Analysis:")
            print(f"   Difference from Current Price: ${difference:+.2f} ({diff_percent:+.1f}%)")
            
            if abs(difference) < 5:
                print(f"   ✅ Current price is very close to optimal!")
            elif difference > 0:
                print(f"   📈 Suggestion: Consider increasing price by ${difference:.2f}")
            else:
                print(f"   📉 Suggestion: Consider decreasing price by ${abs(difference):.2f}")
            
            # Store result
            results.append({
                'product_id': row['product_id'],
                'category': row['product_category'],
                'brand': row['brand'],
                'current_price': actual_price,
                'predicted_price': predicted_price,
                'difference': difference,
                'difference_percent': diff_percent
            })
        
        print()
    
    # Summary Statistics
    print("="*80)
    print("SUMMARY STATISTICS")
    print("="*80)
    
    if results:
        results_df = pd.DataFrame(results)
        
        avg_difference = results_df['difference'].mean()
        avg_abs_difference = results_df['difference'].abs().mean()
        avg_diff_percent = results_df['difference_percent'].abs().mean()
        
        print(f"\nAnalyzed {len(results)} products")
        print(f"Average Price Difference: ${avg_difference:+.2f}")
        print(f"Average Absolute Difference: ${avg_abs_difference:.2f}")
        print(f"Average Deviation: {avg_diff_percent:.1f}%")
        
        # Count recommendations
        increase_count = len(results_df[results_df['difference'] > 5])
        decrease_count = len(results_df[results_df['difference'] < -5])
        optimal_count = len(results_df[abs(results_df['difference']) <= 5])
        
        print(f"\nRecommendations:")
        print(f"   📈 Increase price: {increase_count} products")
        print(f"   📉 Decrease price: {decrease_count} products")
        print(f"   ✅ Already optimal: {optimal_count} products")
    
    print("\n" + "="*80)
    print("Prediction completed successfully!")
    print("="*80)


def predict_single_product():
    """Interactive single product prediction"""
    print("\n" + "="*80)
    print("SINGLE PRODUCT PRICE PREDICTION")
    print("Enter product details below")
    print("="*80)
    
    predictor = PricePredictor()
    
    if predictor.model is None:
        print("❌ Error: Could not load the trained model!")
        return
    
    try:
        # Get user input
        print("\nEnter product information:")
        base_price = float(input("Base Price ($): "))
        competitor_price = float(input("Competitor Price ($): "))
        cost_price = float(input("Cost Price ($): "))
        stock_quantity = int(input("Stock Quantity: "))
        daily_views = int(input("Daily Views: "))
        daily_sales = int(input("Daily Sales: "))
        add_to_cart_count = int(input("Add to Cart Count: "))
        customer_rating = float(input("Customer Rating (1-5): "))
        discount_percentage = float(input("Discount Percentage (%): "))
        advertising_spend = float(input("Advertising Spend ($): "))
        brand = input("Brand (BrandA/BrandB/BrandC/BrandD): ")
        product_category = input("Category (Electronics/Home/Beauty/Clothing): ")
        promotion_type = input("Promotion Type (Sale/Clearance/Festival): ")
        season = input("Season (Summer/Winter/Monsoon/Festival): ")
        day_of_week = int(input("Day of Week (0-6, where 0=Sunday): "))
        demand_index = int(input("Demand Index (1-10): "))
        price_elasticity = float(input("Price Elasticity (0-2): "))
        
        # Prepare product data
        product_data = {
            'base_price': base_price,
            'competitor_price': competitor_price,
            'cost_price': cost_price,
            'stock_quantity': stock_quantity,
            'daily_views': daily_views,
            'daily_sales': daily_sales,
            'add_to_cart_count': add_to_cart_count,
            'customer_rating': customer_rating,
            'discount_percentage': discount_percentage,
            'advertising_spend': advertising_spend,
            'brand': brand,
            'product_category': product_category,
            'promotion_type': promotion_type,
            'season': season,
            'day_of_week': day_of_week,
            'demand_index': demand_index,
            'price_elasticity': price_elasticity
        }
        
        # Make prediction
        result = predictor.predict(product_data)
        
        # Display result
        print("\n" + "="*80)
        print("PREDICTION RESULT")
        print("="*80)
        
        if 'error' in result:
            print(f"❌ Error: {result['error']}")
        else:
            print(f"\n💰 Predicted Optimal Price: ${result['predicted_price']:.2f}")
            print(f"📊 Model Confidence: {result['confidence']}%")
            print(f"🎯 Model Accuracy (R² Score): {result['model_r2_score']}%")
            
            print(f"\n✅ Prediction successful!")
        
        print("="*80)
        
    except ValueError as e:
        print(f"\n❌ Invalid input: {e}")
    except Exception as e:
        print(f"\n❌ Error: {e}")


if __name__ == "__main__":
    print("\n" + "="*80)
    print("DYNAMIC PRICING - REAL DATASET PREDICTIONS")
    print("="*80)
    print("\nChoose prediction mode:")
    print("1. Predict prices for sample products from dataset")
    print("2. Enter custom product details for prediction")
    print("="*80)
    
    choice = input("\nEnter your choice (1 or 2): ")
    
    if choice == "1":
        num_samples = input("How many products to analyze? (default 10): ").strip()
        num_samples = int(num_samples) if num_samples.isdigit() else 10
        predict_from_dataset(num_samples=num_samples)
    elif choice == "2":
        predict_single_product()
    else:
        print("Invalid choice. Please run again and select 1 or 2.")
