"""
Test MongoDB Connection at localhost:27017
"""

from pymongo import MongoClient

print("="*60)
print("🔍 TESTING MONGODB CONNECTION")
print("="*60)
print()

try:
    # Connect to MongoDB
    client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=2000)
    
    # Test connection
    client.server_info()
    
    print("✅ MongoDB connected successfully!")
    print(f"   Address: mongodb://localhost:27017")
    print()
    
    # List all databases
    databases = client.list_database_names()
    print(f"📊 Available Databases ({len(databases)}):")
    for db in databases:
        print(f"   • {db}")
    print()
    
    # Connect to our database
    db = client['dynamic_pricing_db']
    print(f"🗄️  Selected Database: dynamic_pricing_db")
    print()
    
    # List collections
    collections = db.list_collection_names()
    print(f"📋 Collections in dynamic_pricing_db ({len(collections)}):")
    if collections:
        for col in collections:
            count = db[col].count_documents({})
            print(f"   • {col} ({count} documents)")
    else:
        print("   (no collections yet - will be created on first prediction)")
    print()
    
    # Check predictions collection
    if 'predictions' in collections:
        predictions_col = db['predictions']
        count = predictions_col.count_documents({})
        print(f"✅ Predictions collection ready with {count} documents")
        
        # Show latest prediction if exists
        if count > 0:
            latest = predictions_col.find_one(sort=[('timestamp', -1)])
            print(f"\n📝 Latest Prediction:")
            print(f"   ID: {latest['_id']}")
            print(f"   Timestamp: {latest['timestamp']}")
            print(f"   Predicted Price: ${latest['predicted_price']:.2f}")
            print(f"   Product: {latest['product_category']} - {latest['brand']}")
    else:
        print("ℹ️  Predictions collection will be created when you make your first prediction")
    
    print()
    print("="*60)
    print("✅ MONGODB IS READY!")
    print("="*60)
    print()
    print("Next steps:")
    print("1. Start the Flask server: python app_with_mongodb.py")
    print("2. Open browser: http://localhost:5000")
    print("3. Make a prediction - it will auto-save to MongoDB")
    print("4. Click 'View History' button to see all predictions")
    print()

except Exception as e:
    print(f"❌ MongoDB connection failed!")
    print(f"   Error: {e}")
    print()
    print("Troubleshooting:")
    print("1. Make sure MongoDB is running:")
    print("   mongod --dbpath \"C:\\data\\db\"")
    print()
    print("2. Install pymongo if not installed:")
    print("   pip install pymongo")
    print()
    print("3. Check MongoDB service status:")
    print("   Windows: services.msc → Look for MongoDB Server")
