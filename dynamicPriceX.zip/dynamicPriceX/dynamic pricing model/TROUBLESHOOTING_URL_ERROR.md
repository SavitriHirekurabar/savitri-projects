# 🔧 Troubleshooting Guide - "URL Not Found" Error

## Problem
You're getting this error:
```
The requested URL was not found on the server.
```

## ✅ SOLUTION - Use the Fixed Server

### Quick Fix (One Click)
**Double-click this file:**
```
START_FIXED_SERVER.bat
```

This will:
1. Start the fixed Flask server
2. Open your browser automatically
3. Try multiple URLs to ensure it works

---

## 🎯 Alternative: Manual Start

### Step 1: Stop Any Running Flask Servers
If you have any Flask servers running, stop them (Ctrl+C in their terminal)

### Step 2: Start the Fixed Server
```bash
python fixed_app.py
```

### Step 3: Open Browser to These URLs (try in order)
1. **Main Form**: http://localhost:5000/ml_prediction_form.html
2. **Home**: http://localhost:5000/
3. **API Info**: http://localhost:5000/api/model-info

---

## 🔍 What Was Fixed

The `fixed_app.py` includes:

1. **Better File Serving**
   - Checks if file exists before serving
   - Has explicit route for `/ml_prediction_form.html`
   - Better error handling

2. **Multiple Routes**
   - Both `/` and `/ml_prediction_form.html` serve the form
   - Fallback error messages if file not found

3. **Enhanced Logging**
   - Shows exactly what's being served
   - Better debugging information

---

## 📋 Still Not Working? Try These

### Check 1: Verify Files Exist
```bash
dir ml_prediction_form.html
dir fixed_app.py
dir pricing_model.pkl
```

All three should exist in your folder.

### Check 2: Make Sure Port 5000 is Free
Close any other programs using port 5000, or try:
```bash
python fixed_app.py
```
Look for "Running on http://0.0.0.0:5000"

### Check 3: Test API Directly
While server is running, open browser to:
```
http://localhost:5000/api/model-info
```

If you see JSON with model info, the server IS working!

### Check 4: Check Browser Console
1. Open browser DevTools (F12)
2. Go to Console tab
3. Look for errors

Common fixes:
- Clear browser cache (Ctrl+Shift+Delete)
- Hard refresh (Ctrl+F5)
- Try incognito/private mode

---

## 🚨 Common Errors & Solutions

### Error: "Address already in use"
**Solution:** Another program is using port 5000
```bash
# Find and kill process using port 5000 (Windows)
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F
```

### Error: "ModuleNotFoundError: No module named 'flask'"
**Solution:** Install Flask
```bash
pip install flask
```

### Error: Page shows but prediction doesn't work
**Solution:** Check if model is trained
```bash
python verify_model.py
```

### Error: "Model not loaded"
**Solution:** Train the model first
```bash
python pricing_model.py
```

---

## ✅ Success Indicators

You'll know it's working when:

1. ✅ Terminal shows: "Running on http://0.0.0.0:5000"
2. ✅ Browser opens to ML prediction form
3. ✅ All 17 input fields are visible
4. ✅ Submit button is clickable
5. ✅ Predictions return results
6. ✅ Terminal shows prediction logs

---

## 📞 Quick Diagnostic Commands

### Is Flask Running?
Check terminal for:
```
* Running on http://0.0.0.0:5000
```

### Is Model Loaded?
Look for in terminal:
```
✅ ML Model loaded successfully
   Model type: LinearRegression
   Accuracy: 95.19%
```

### Can You Access API?
Visit in browser:
```
http://localhost:5000/api/model-info
```

Should show JSON like:
```json
{
  "model_type": "Linear Regression",
  "accuracy": 95.19,
  "feature_count": 17
}
```

---

## 🎯 Best Solution

**Just use the fixed batch file:**
```
Double-click: START_FIXED_SERVER.bat
```

It handles everything automatically! 🚀

---

**Last Updated:** 2026  
**Status:** Fixed & Ready ✓
