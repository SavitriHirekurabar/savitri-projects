@echo off
cls
echo ================================================================
echo           DYNAMIC MARKETING PRICING MODEL - QUICK START
echo ================================================================
echo.

:menu
echo.
echo Please select an option:
echo.
echo 1. Install Required Packages
echo 2. Train the ML Model
echo 3. Test Price Predictions (Demo)
echo 4. Start Web Server (Flask API)
echo 5. View Model Information
echo 6. Exit
echo.
set /p choice="Enter your choice (1-6): "

if "%choice%"=="1" goto install
if "%choice%"=="2" goto train
if "%choice%"=="3" goto demo
if "%choice%"=="4" goto server
if "%choice%"=="5" goto info
if "%choice%"=="6" goto end
goto menu

:install
echo.
echo ================================================================
echo Installing Required Packages...
echo ================================================================
pip install pandas numpy scikit-learn joblib flask
echo.
echo Installation complete!
pause
goto menu

:train
echo.
echo ================================================================
echo Training the Machine Learning Model...
echo ================================================================
python pricing_model.py
echo.
pause
goto menu

:demo
echo.
echo ================================================================
echo Running Price Prediction Demo...
echo ================================================================
python predict_price.py
echo.
pause
goto menu

:server
echo.
echo ================================================================
echo Starting Flask Web Server...
echo ================================================================
echo The server will be available at: http://localhost:5000
echo Press Ctrl+C to stop the server
echo.
python flask_app.py
goto menu

:info
echo.
echo ================================================================
echo Model Information
echo ================================================================
if exist model_metadata.json (
    type model_metadata.json
) else (
    echo Model not trained yet. Please train the model first.
)
echo.
pause
goto menu

:end
echo.
echo Thank you for using Dynamic Marketing Pricing Model!
echo.
exit
