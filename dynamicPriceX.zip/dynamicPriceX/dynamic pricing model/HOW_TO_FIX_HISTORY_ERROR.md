# 🔧 How to Fix History Page Connection Error

## ❌ Problem

You're seeing this error on the history page:
```
⚠️ Could not connect to server
Could not load history
Make sure MongoDB is running and the server was started with app_with_mongodb.py
```

---

## ✅ Solution (3 Easy Steps)

### **Option 1: Quick Start (Recommended)**

**Double-click this file:**
```
START_MONGODB_SERVER.bat
```

This will:
1. ✅ Start Flask server with MongoDB support
2. ✅ Open your browser automatically
3. ✅ Ready to make predictions and view history

---

### **Option 2: Manual Start**

**Step 1: Start Flask Server with MongoDB**
```bash
python app_with_mongodb.py
```

**Look for this output:**
```
✓ MongoDB connected successfully
  Database: dynamic_pricing_db
  Collection: predictions
✓ ML Model loaded successfully
* Running on http://127.0.0.1:5000
```

**Step 2: Open Browser**
Visit either:
- http://localhost:5000/dynamic_pricing_v2.html (make predictions)
- http://localhost:5000/mongodb_history_viewer.html (view history)

**Step 3: Click "View History" Button**
The button in the top-left corner will now work!

---

## 🎯 Why This Happens

The history page needs the Flask server running because:
1. It fetches data from `/api/history` endpoint
2. The endpoint is only available when server is running
3. Server connects to MongoDB and retrieves predictions

**Without the server running, the history page can't fetch data!**

---

## 🔍 Check If Server Is Running

**Test the API:**
Open browser to:
```
http://localhost:5000/api/statistics
```

**If you see JSON like this, server IS running:**
```json
{
  "success": true,
  "statistics": {
    "total_predictions": 0,
    "average_price": 0,
    ...
  }
}
```

**If you see connection error, server is NOT running.**
Start it with: `python app_with_mongodb.py`

---

## 📋 Complete Checklist

To use the history feature, you need:

- [x] **MongoDB running** at localhost:27017 ✅ (already working!)
- [x] **pymongo installed** (`pip install pymongo`) ✅
- [ ] **Flask server running** (`python app_with_mongodb.py`) ← START THIS
- [ ] **Browser opened** to history page

---

## 🆘 Still Not Working?

### Issue: "ModuleNotFoundError: No module named 'pymongo'"

**Solution:**
```bash
pip install pymongo
```

### Issue: "MongoDB connection failed"

**Check MongoDB is running:**
```bash
# Windows - check Services
services.msc
# Look for "MongoDB Server" - should be "Running"
```

**Or start manually:**
```bash
mongod --dbpath "C:\data\db"
```

### Issue: "Address already in use"

**Another program is using port 5000.**

**Solution 1:** Find and stop it
```bash
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F
```

**Solution 2:** Use different port
Edit `app_with_mongodb.py`, change line:
```python
app.run(debug=True, host='0.0.0.0', port=5001)  # Use 5001 instead
```

---

## 🎯 Quick Test (30 Seconds)

**Right now, try this:**

1. **Start server:**
   ```bash
   python app_with_mongodb.py
   ```

2. **Wait for:**
   ```
   ✓ MongoDB connected successfully
   * Running on http://127.0.0.1:5000
   ```

3. **Open browser:**
   ```
   http://localhost:5000/mongodb_history_viewer.html
   ```

4. **Should see:**
   - Statistics cards (Total Predictions, Average Price, etc.)
   - Empty state or prediction table
   - NO error messages!

---

## ✅ Success Indicators

You'll know it's working when:

1. ✅ Terminal shows: `✓ MongoDB connected successfully`
2. ✅ Terminal shows: `* Running on http://127.0.0.1:5000`
3. ✅ History page loads WITHOUT error
4. ✅ Statistics show numbers (or 0 if no predictions yet)
5. ✅ Can click "View History" button successfully

---

## 📞 Summary

**Problem:** History page shows connection error  
**Cause:** Flask server with MongoDB not running  
**Fix:** Run `python app_with_mongodb.py` or double-click `START_MONGODB_SERVER.bat`

**Easiest solution:**
```
Double-click: START_MONGODB_SERVER.bat
```

It starts everything automatically! 🚀

---

**Created:** March 14, 2026  
**Status:** ✅ FIXED - Server is now running!  
**Next:** Refresh your history page and it should work!
