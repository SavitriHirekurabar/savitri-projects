"""
Create MongoDB Database and Collections for Dynamic Pricing
"""

from pymongo import MongoClient
from datetime import datetime, timedelta

print("="*60)
print("🔧 CREATING MONGODB DATABASE AND COLLECTIONS")
print("="*60)
print()

try:
    # Connect to MongoDB
    client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=2000)
    
    # Test connection
    client.server_info()
    print("✅ Connected to MongoDB")
    print()
    
    # Create/select database
    db = client['dynamic_pricing_db']
    print("📊 Database: dynamic_pricing_db")
    print()
    
    # Create collections if they don't exist
    collections = db.list_collection_names()
    
    if 'predictions' not in collections:
        # Create predictions collection
        db.create_collection('predictions')
        print("✅ Created collection: predictions")
        
        # Insert sample predictions
        sample_predictions = [
            {
                "timestamp": datetime.utcnow() - timedelta(days=5),
                "product_data": {
                    "base_price": 500,
                    "competitor_price": 520,
                    "cost_price": 350,
                    "stock_quantity": 200,
                    "daily_views": 3000,
                    "daily_sales": 100,
                    "add_to_cart_count": 150,
                    "customer_rating": 4.5,
                    "discount_percentage": 20,
                    "advertising_spend": 2000,
                    "brand": "BrandA",
                    "product_category": "Electronics",
                    "promotion_type": "Sale",
                    "season": "Summer",
                    "day_of_week": 5,
                    "demand_index": 7,
                    "price_elasticity": 1.5
                },
                "prediction_result": {
                    "predicted_price": 450.75,
                    "confidence": 95.19,
                    "model_r2_score": 95.19,
                    "recommendation": "Decrease price by $49.25"
                },
                "predicted_price": 450.75,
                "base_price": 500,
                "difference": -49.25,
                "confidence": 95.19,
                "product_category": "Electronics",
                "brand": "BrandA"
            },
            {
                "timestamp": datetime.utcnow() - timedelta(days=3),
                "product_data": {
                    "base_price": 800,
                    "competitor_price": 850,
                    "cost_price": 600,
                    "stock_quantity": 150,
                    "daily_views": 2500,
                    "daily_sales": 80,
                    "add_to_cart_count": 120,
                    "customer_rating": 4.2,
                    "discount_percentage": 15,
                    "advertising_spend": 2500,
                    "brand": "BrandB",
                    "product_category": "Home",
                    "promotion_type": "Clearance",
                    "season": "Winter",
                    "day_of_week": 3,
                    "demand_index": 6,
                    "price_elasticity": 1.2
                },
                "prediction_result": {
                    "predicted_price": 825.50,
                    "confidence": 94.85,
                    "model_r2_score": 95.19,
                    "recommendation": "Increase price by $25.50"
                },
                "predicted_price": 825.50,
                "base_price": 800,
                "difference": 25.50,
                "confidence": 94.85,
                "product_category": "Home",
                "brand": "BrandB"
            },
            {
                "timestamp": datetime.utcnow() - timedelta(days=1),
                "product_data": {
                    "base_price": 350,
                    "competitor_price": 340,
                    "cost_price": 250,
                    "stock_quantity": 300,
                    "daily_views": 4000,
                    "daily_sales": 150,
                    "add_to_cart_count": 200,
                    "customer_rating": 4.7,
                    "discount_percentage": 25,
                    "advertising_spend": 1800,
                    "brand": "BrandC",
                    "product_category": "Beauty",
                    "promotion_type": "Festival",
                    "season": "Monsoon",
                    "day_of_week": 6,
                    "demand_index": 8,
                    "price_elasticity": 1.8
                },
                "prediction_result": {
                    "predicted_price": 365.25,
                    "confidence": 95.42,
                    "model_r2_score": 95.19,
                    "recommendation": "Increase price by $15.25"
                },
                "predicted_price": 365.25,
                "base_price": 350,
                "difference": 15.25,
                "confidence": 95.42,
                "product_category": "Beauty",
                "brand": "BrandC"
            }
        ]
        
        # Insert sample data
        result = db.predictions.insert_many(sample_predictions)
        print(f"✅ Inserted {len(result.inserted_ids)} sample predictions")
        print()
        
    else:
        print("ℹ️  Collection 'predictions' already exists")
        count = db.predictions.count_documents({})
        print(f"   Contains {count} documents")
        print()
    
    # Verify creation
    collections = db.list_collection_names()
    print(f"📋 Collections in dynamic_pricing_db:")
    for col in collections:
        count = db[col].count_documents({})
        print(f"   • {col} ({count} documents)")
    print()
    
    # Show latest prediction
    print("📝 Latest Prediction:")
    latest = db.predictions.find_one(sort=[('timestamp', -1)])
    if latest:
        print(f"   Product: {latest['product_category']} - {latest['brand']}")
        print(f"   Predicted Price: ${latest['predicted_price']:.2f}")
        print(f"   Confidence: {latest['confidence']:.1f}%")
        print(f"   Timestamp: {latest['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    print("="*60)
    print("✅ DATABASE SETUP COMPLETE!")
    print("="*60)
    print()
    print("You can now:")
    print("1. View history at: http://localhost:5000/mongodb_history_viewer.html")
    print("2. Click 'View History' button in the prediction form")
    print("3. See your sample predictions in the table!")
    print()

except Exception as e:
    print(f"❌ Error: {e}")
    print()
    print("Make sure:")
    print("1. MongoDB is running on localhost:27017")
    print("2. pymongo is installed: pip install pymongo")
