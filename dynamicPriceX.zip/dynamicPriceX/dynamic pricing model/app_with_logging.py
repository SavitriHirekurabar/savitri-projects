from flask import Flask, request, jsonify, send_from_directory
from predict_price import PricePredictor
import datetime

app = Flask(__name__)

# Initialize the price predictor
predictor = None
prediction_count = 0

try:
    predictor = PricePredictor('pricing_model.pkl')
    print("✅ ML Model loaded successfully")
    print(f"   Model type: {type(predictor.model).__name__}")
    print(f"   Accuracy: {predictor.metadata['metrics']['test_r2']*100:.2f}%")
except Exception as e:
    print(f"⚠ Warning: Could not load model - {e}")
    print("Please run 'python pricing_model.py' to train the model first")


@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'dynamic_pricing_v2.html')


@app.route('/api/predict', methods=['POST'])
def predict():
    """
    API endpoint for price prediction from frontend
    
    Expected JSON format from frontend form
    """
    global prediction_count
    
    if predictor is None:
        return jsonify({
            'error': 'Model not loaded. Please train the model first.',
            'instruction': 'Run: python pricing_model.py'
        }), 503
    
    try:
        product_data = request.get_json()
        
        if not product_data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Log prediction request
        timestamp = datetime.datetime.now().isoformat()
        prediction_count += 1
        
        print("\n" + "="*70)
        print(f"🔮 ML PREDICTION REQUEST #{prediction_count}")
        print("="*70)
        print(f"   Timestamp: {timestamp}")
        print(f"   Product: {product_data.get('product_category', 'Unknown')} - {product_data.get('brand', 'Unknown')}")
        print(f"   Base Price: ${product_data.get('base_price', 0):.2f}")
        
        # Make prediction using trained model
        print(f"\n📊 Processing with Trained Linear Regression Model...")
        result = predictor.predict(product_data)
        
        if 'error' in result:
            print(f"❌ Prediction Error: {result['error']}")
            return jsonify(result), 400
        
        # Log prediction result
        print(f"\n✅ PREDICTION COMPLETE:")
        print(f"   Predicted Price: ${result['predicted_price']:.2f}")
        print(f"   Confidence: {result['confidence']}%")
        print(f"   Model R² Score: {result['model_r2_score']}%")
        
        # Add additional insights
        base_price = float(product_data.get('base_price', 0))
        predicted_price = result['predicted_price']
        
        if base_price > 0:
            difference = predicted_price - base_price
            diff_percent = (difference / base_price) * 100
            
            result['base_price'] = base_price
            result['difference'] = round(difference, 2)
            result['difference_percent'] = round(diff_percent, 1)
            
            print(f"\n💡 Analysis:")
            print(f"   Difference from Base: ${difference:+.2f} ({diff_percent:+.1f}%)")
            
            # Generate recommendation
            if abs(difference) <= 5:
                result['recommendation'] = 'Price is optimal'
                result['action'] = 'keep'
                print(f"   Recommendation: ✅ Price is optimal")
            elif difference > 0:
                result['recommendation'] = f'Increase price by ${difference:.2f}'
                result['action'] = 'increase'
                print(f"   Recommendation: 📈 Increase price by ${difference:.2f}")
            else:
                result['recommendation'] = f'Decrease price by ${abs(difference):.2f}'
                result['action'] = 'decrease'
                print(f"   Recommendation: 📉 Decrease price by ${abs(difference):.2f}")
        
        print(f"\n📝 Verification:")
        print(f"   ✓ Used trained model: {type(predictor.model).__name__}")
        print(f"   ✓ Features analyzed: {len(predictor.feature_columns)}")
        print(f"   ✓ Model accuracy: {predictor.metadata['metrics']['test_r2']*100:.2f}%")
        print("="*70 + "\n")
        
        return jsonify(result)
    
    except Exception as e:
        print(f"❌ Error during prediction: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict-bulk', methods=['POST'])
def predict_bulk():
    """
    API endpoint for bulk price predictions
    """
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    try:
        data = request.get_json()
        products = data.get('products', [])
        
        if not products:
            return jsonify({'error': 'No products provided'}), 400
        
        print(f"\n📦 Bulk prediction request: {len(products)} products")
        results = predictor.predict_bulk(products)
        print(f"✅ Completed {len(results)} predictions")
        
        return jsonify({'predictions': results})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/model-info', methods=['GET'])
def model_info():
    """Get model information and metrics"""
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    info = {
        'model_type': predictor.metadata.get('model_type', 'Linear Regression'),
        'training_date': predictor.metadata.get('training_date', 'Unknown'),
        'features': predictor.feature_columns,
        'metrics': predictor.metadata.get('metrics', {}),
        'accuracy': round(predictor.metadata['metrics']['test_r2'] * 100, 2),
        'total_predictions': prediction_count,
        'model_file': 'pricing_model.pkl',
        'feature_count': len(predictor.feature_columns)
    }
    
    print(f"\n📊 Model info requested")
    print(f"   Total predictions made: {prediction_count}")
    
    return jsonify(info)


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Dynamic Pricing API Server with ML Model")
    print("="*60)
    print("\nStarting Flask server...")
    print("Access the app at: http://localhost:5000")
    print(f"\n✅ ML Model Status:")
    if predictor:
        print(f"   • Model loaded: pricing_model.pkl")
        print(f"   • Model type: {type(predictor.model).__name__}")
        print(f"   • Accuracy: {predictor.metadata['metrics']['test_r2']*100:.2f}%")
        print(f"   • Features: {len(predictor.feature_columns)} input variables")
    else:
        print(f"   ⚠️  Model NOT loaded - Run: python pricing_model.py")
    
    print("\n📋 API Endpoints:")
    print("  POST /api/predict      - Single price prediction (with logging)")
    print("  POST /api/predict-bulk - Bulk price predictions")
    print("  GET  /api/model-info   - Model information & stats")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
