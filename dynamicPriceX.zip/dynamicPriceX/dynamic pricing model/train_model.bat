@echo off
echo ========================================
echo Dynamic Marketing Pricing Model
echo Installing Required Packages...
echo ========================================

pip install pandas numpy scikit-learn joblib

echo.
echo ========================================
echo Training the Model...
echo ========================================

python pricing_model.py

echo.
echo ========================================
echo Process Complete!
echo ========================================
pause
