@echo off
cls
echo ================================================================================
echo                    STARTING ML-POWERED DYNAMIC PRICING SYSTEM
echo ================================================================================
echo.
echo Starting Flask Backend Server...
echo.

cd /d "%~dp0"

start "Flask ML Server" cmd /c "python app.py"

echo.
echo Waiting for server to start...
timeout /t 3 /nobreak >nul

echo.
echo Opening ML Prediction Interface in your browser...
echo.
echo ================================================================================
echo 
echo ✅ Backend: Flask API running at http://localhost:5000
echo ✅ Frontend: ML Prediction Form opening now
echo.
echo API Endpoints available:
echo   - POST /api/predict      : Get price prediction
echo   - GET  /api/model-info   : Model information
echo.
echo Press Ctrl+C in the Flask window to stop the server
echo ================================================================================
echo.

start http://localhost:5000/ml_prediction_form.html

pause
