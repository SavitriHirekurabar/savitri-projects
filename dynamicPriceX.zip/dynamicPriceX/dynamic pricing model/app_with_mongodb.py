from flask import Flask, request, jsonify, send_from_directory
from predict_price import PricePredictor
from pymongo import MongoClient
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Initialize the price predictor
predictor = None

# Initialize MongoDB connection
mongo_client = None
db = None
predictions_collection = None

try:
    # Connect to MongoDB (localhost:27017 by default)
    mongo_client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=2000)
    db = mongo_client['dynamic_pricing_db']
    predictions_collection = db['predictions']
    
    # Test connection
    mongo_client.server_info()
    print("✓ MongoDB connected successfully")
    print("  Database: dynamic_pricing_db")
    print("  Collection: predictions")
except Exception as e:
    print(f"⚠ MongoDB connection warning: {e}")
    print("  History will not be saved. Install pymongo: pip install pymongo")
    print("  Make sure MongoDB is running on localhost:27017")

try:
    predictor = PricePredictor('pricing_model.pkl')
    print("✓ ML Model loaded successfully")
except Exception as e:
    print(f"⚠ Warning: Could not load model - {e}")
    print("Please run 'python pricing_model.py' to train the model first")


@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'dynamic_pricing_v2.html')


@app.route('/api/predict', methods=['POST'])
def predict():
    """
    API endpoint for price prediction from frontend
    """
    if predictor is None:
        return jsonify({
            'error': 'Model not loaded. Please train the model first.',
            'instruction': 'Run: python pricing_model.py'
        }), 503
    
    try:
        product_data = request.get_json()
        
        if not product_data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Make prediction using trained model
        result = predictor.predict(product_data)
        
        if 'error' in result:
            return jsonify(result), 400
        
        # Add additional insights
        base_price = float(product_data.get('base_price', 0))
        predicted_price = result['predicted_price']
        
        if base_price > 0:
            difference = predicted_price - base_price
            diff_percent = (difference / base_price) * 100
            
            result['base_price'] = base_price
            result['difference'] = round(difference, 2)
            result['difference_percent'] = round(diff_percent, 1)
            
            # Generate recommendation
            if abs(difference) <= 5:
                result['recommendation'] = 'Price is optimal'
                result['action'] = 'keep'
            elif difference > 0:
                result['recommendation'] = f'Increase price by ${difference:.2f}'
                result['action'] = 'increase'
            else:
                result['recommendation'] = f'Decrease price by ${abs(difference):.2f}'
                result['action'] = 'decrease'
        
        # Save to MongoDB
        if predictions_collection:
            try:
                prediction_doc = {
                    'timestamp': datetime.utcnow(),
                    'product_data': product_data,
                    'prediction_result': result,
                    'predicted_price': predicted_price,
                    'base_price': base_price,
                    'difference': round(difference, 2),
                    'confidence': result.get('confidence', 0),
                    'product_category': product_data.get('product_category', 'Unknown'),
                    'brand': product_data.get('brand', 'Unknown')
                }
                
                inserted = predictions_collection.insert_one(prediction_doc)
                print(f"✓ Prediction saved to MongoDB (ID: {inserted.inserted_id})")
                
                # Add MongoDB ID to response
                result['history_id'] = str(inserted.inserted_id)
                result['saved_to_history'] = True
                
            except Exception as db_error:
                print(f"⚠ Could not save to MongoDB: {db_error}")
                result['saved_to_history'] = False
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history', methods=['GET'])
def get_history():
    """Get prediction history from MongoDB"""
    if not predictions_collection:
        return jsonify({
            'error': 'MongoDB not connected',
            'predictions': []
        }), 503
    
    try:
        limit = request.args.get('limit', 100, type=int)
        
        # Query and sort by timestamp descending
        cursor = predictions_collection.find().sort('timestamp', -1).limit(limit)
        
        predictions = []
        for doc in cursor:
            doc['_id'] = str(doc['_id'])
            doc['timestamp'] = doc['timestamp'].isoformat()
            predictions.append(doc)
        
        return jsonify({
            'success': True,
            'count': len(predictions),
            'predictions': predictions
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Get prediction statistics from MongoDB"""
    if not predictions_collection:
        return jsonify({
            'error': 'MongoDB not connected'
        }), 503
    
    try:
        # Total predictions
        total_predictions = predictions_collection.count_documents({})
        
        # Average predicted price
        avg_price_pipeline = [
            {'$group': {'_id': None, 'avg_price': {'$avg': '$predicted_price'}}}
        ]
        avg_price_result = list(predictions_collection.aggregate(avg_price_pipeline))
        avg_price = avg_price_result[0]['avg_price'] if avg_price_result else 0
        
        # Average confidence
        avg_conf_pipeline = [
            {'$group': {'_id': None, 'avg_confidence': {'$avg': '$confidence'}}}
        ]
        avg_conf_result = list(predictions_collection.aggregate(avg_conf_pipeline))
        avg_confidence = avg_conf_result[0]['avg_confidence'] if avg_conf_result else 0
        
        # Predictions by category
        category_pipeline = [
            {'$group': {'_id': '$product_category', 'count': {'$sum': 1}}},
            {'$sort': {'count': -1}}
        ]
        by_category = list(predictions_collection.aggregate(category_pipeline))
        
        # Predictions by brand
        brand_pipeline = [
            {'$group': {'_id': '$brand', 'count': {'$sum': 1}}},
            {'$sort': {'count': -1}}
        ]
        by_brand = list(predictions_collection.aggregate(brand_pipeline))
        
        # Recent activity (last 7 days)
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        recent_count = predictions_collection.count_documents({
            'timestamp': {'$gte': seven_days_ago}
        })
        
        return jsonify({
            'success': True,
            'statistics': {
                'total_predictions': total_predictions,
                'average_price': round(avg_price, 2),
                'average_confidence': round(avg_confidence, 1),
                'by_category': {item['_id']: item['count'] for item in by_category},
                'by_brand': {item['_id']: item['count'] for item in by_brand},
                'recent_predictions': recent_count
            }
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history/<pred_id>', methods=['DELETE'])
def delete_prediction(pred_id):
    """Delete a specific prediction from MongoDB"""
    if not predictions_collection:
        return jsonify({'error': 'MongoDB not connected'}), 503
    
    try:
        from bson import ObjectId
        result = predictions_collection.delete_one({'_id': ObjectId(pred_id)})
        
        if result.deleted_count > 0:
            return jsonify({
                'success': True,
                'message': f'Deleted prediction {pred_id}'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Prediction not found'
            }), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/history/clear', methods=['POST'])
def clear_history():
    """Clear all prediction history"""
    if not predictions_collection:
        return jsonify({'error': 'MongoDB not connected'}), 503
    
    try:
        result = predictions_collection.delete_many({})
        return jsonify({
            'success': True,
            'message': f'Cleared {result.deleted_count} predictions'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/model-info', methods=['GET'])
def model_info():
    """Get model information and metrics"""
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    return jsonify({
        'model_type': predictor.metadata.get('model_type', 'Linear Regression'),
        'training_date': predictor.metadata.get('training_date', 'Unknown'),
        'features': predictor.feature_columns,
        'metrics': predictor.metadata.get('metrics', {}),
        'accuracy': round(predictor.metadata['metrics']['test_r2'] * 100, 2)
    })


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Dynamic Pricing API Server with MongoDB History")
    print("="*60)
    print("\nStarting Flask server...")
    print("Access the app at: http://localhost:5000")
    print(f"\n✅ Services:")
    if mongo_client:
        print(f"   ✓ MongoDB: Connected (dynamic_pricing_db.predictions)")
    else:
        print(f"   ⚠ MongoDB: Not connected (install pymongo + start MongoDB)")
    
    if predictor:
        print(f"   ✓ ML Model: Loaded (pricing_model.pkl)")
        print(f"   ✓ Accuracy: {predictor.metadata['metrics']['test_r2']*100:.2f}%")
    else:
        print(f"   ⚠ ML Model: Not loaded - Run: python pricing_model.py")
    
    print("\n📋 API Endpoints:")
    print("  POST /api/predict      - Single price prediction (saves to MongoDB)")
    print("  GET  /api/history      - Get prediction history")
    print("  GET  /api/statistics   - Get prediction statistics")
    print("  DELETE /api/history/:id - Delete specific prediction")
    print("  POST /api/history/clear - Clear all history")
    print("  GET  /api/model-info   - Model information")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
