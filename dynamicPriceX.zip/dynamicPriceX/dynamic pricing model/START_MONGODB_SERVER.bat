@echo off
cls
echo ================================================================================
echo                    STARTING ML SYSTEM WITH MONGODB HISTORY
echo ================================================================================
echo.
echo Starting Flask Backend Server (with MongoDB History Integration)...
echo.

cd /d "%~dp0"

start "Flask ML Server with MongoDB" cmd /c "python app_with_mongodb.py"

echo.
echo Waiting for server to start...
timeout /t 3 /nobreak >nul

echo.
echo Opening ML Prediction Interface in your browser...
echo.
echo ================================================================================
echo 
echo ✅ Backend: Flask API running at http://localhost:5000
echo ✅ Features: ML Predictions + MongoDB History Tracking
echo ✅ Database: MongoDB (dynamic_pricing_db.predictions)
echo.
echo Prerequisites:
echo   • MongoDB must be running on localhost:27017
echo   • Install pymongo if not installed: pip install pymongo
echo.
echo URLs to try:
echo   • http://localhost:5000/dynamic_pricing_v2.html - Make predictions
echo   • http://localhost:5000/mongodb_history_viewer.html - View history
echo   • http://localhost:5000/api/history - Get history JSON
echo   • http://localhost:5000/api/statistics - Get stats
echo.
echo Press Ctrl+C in the Flask window to stop the server
echo ================================================================================
echo.

REM Open prediction form
start http://localhost:5000/dynamic_pricing_v2.html

pause
