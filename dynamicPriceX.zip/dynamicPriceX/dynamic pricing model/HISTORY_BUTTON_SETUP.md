# 📊 History Button Setup Guide

## ✅ What Was Added

I've added a **View History** button to your `dynamic_pricing_v2.html` file that connects to MongoDB for storing and viewing prediction history.

---

## 🎯 Where Is the Button?

The button is now visible in the **top-left corner** of your prediction form header:

```
┌─────────────────────────────────────────────┐
│ [📊 View History]                           │ ← BUTTON HERE
│                                             │
│     DynamicPriceX - Price Predector         │
│     Professional Price Optimization Engine  │
│                                             │
└─────────────────────────────────────────────┘
```

---

## 🚀 How to Use

### Step 1: Install Prerequisites

```bash
# Install pymongo
pip install pymongo

# Make sure MongoDB is running on localhost:27017
```

### Step 2: Start the Server with MongoDB Support

```bash
python app_with_mongodb.py
```

### Step 3: Open Your Prediction Form

Visit: http://localhost:5000

You'll see the **"📊 View History"** button in the top-left corner!

### Step 4: Click the Button

Clicking it takes you to: `mongodb_history_viewer.html`

Where you can:
- ✅ See all predictions stored in MongoDB
- ✅ View statistics (total, average price, confidence)
- ✅ Filter and search predictions
- ✅ Delete individual predictions
- ✅ Clear all history

---

## 📁 Files Modified/Created

| File | Status | Purpose |
|------|--------|---------|
| `dynamic_pricing_v2.html` | ✅ Modified | Added history button in header |
| `mongodb_history_viewer.html` | ✅ Created | Beautiful history viewer page |
| `app_with_mongodb.py` | ✅ Created | Flask server with MongoDB integration |

---

## 🔧 How It Works

### 1. **Make a Prediction**
- Fill out form in `dynamic_pricing_v2.html`
- Submit prediction
- Backend (`app_with_mongodb.py`) processes with ML model
- **Automatically saves to MongoDB**

### 2. **View History**
- Click "📊 View History" button
- Opens `mongodb_history_viewer.html`
- Fetches data from MongoDB
- Displays in beautiful table with statistics

### 3. **MongoDB Structure**

**Database:** `dynamic_pricing_db`  
**Collection:** `predictions`

Each prediction stores:
```javascript
{
    _id: ObjectId("..."),
    timestamp: Date,
    product_data: { /* all input fields */ },
    prediction_result: { /* ML result */ },
    predicted_price: Number,
    base_price: Number,
    difference: Number,
    confidence: Number,
    product_category: String,
    brand: String
}
```

---

## ⚠️ Important Notes

### MongoDB Must Be Running

If MongoDB isn't running, you'll see:
```
⚠ MongoDB connection warning: localhost:27017 refused
History will not be saved
```

**Solution:**
```bash
# Start MongoDB
mongod --dbpath "C:\data\db"
```

### Use the Right Server File

**For history feature:**
```bash
python app_with_mongodb.py  # ✓ Use this
```

**Without history:**
```bash
python app.py  # ✗ Won't save to MongoDB
```

---

## 🎨 What You'll See

### Prediction Form (with Button)
```
┌──────────────────────────────────────────┐
│ [📊 View History]                        │
│                                          │
│   DynamicPriceX - Price Predector        │
│   [Form fields...]                       │
│   [Predict Button]                       │
└──────────────────────────────────────────┘
```

### History Viewer Page
```
┌──────────────────────────────────────────┐
│ 📊 Prediction History [MongoDB]          │
│                                          │
│ [Total: 50] [Avg: $485] [Conf: 95%] ... │
│                                          │
│ ┌──────────────────────────────────────┐│
│ │ ID | Date | Product | Price | Diff  ││
│ ├──────────────────────────────────────┤│
│ │ .. | ...  | Elec..  | $515  | +$15 ││
│ └──────────────────────────────────────┘│
│                                          │
│ [← Back] [🗑️ Clear All]                 │
└──────────────────────────────────────────┘
```

---

## 🆘 Troubleshooting

### Issue: Button doesn't work

**Check:**
1. Is server running? `python app_with_mongodb.py`
2. Is MongoDB running? Check port 27017
3. Is `mongodb_history_viewer.html` in same folder?

### Issue: "MongoDB not connected"

**Solutions:**
```bash
# Install pymongo
pip install pymongo

# Start MongoDB service
mongod --dbpath "C:\data\db"

# Restart Flask server
```

### Issue: No predictions showing

**Reason:** You haven't made any predictions yet with the MongoDB-enabled server

**Solution:**
1. Start: `python app_with_mongodb.py`
2. Make a prediction via form
3. Click "View History" - it will be there!

---

## 🎯 Quick Test (1 Minute)

```bash
# 1. Install pymongo
pip install pymongo

# 2. Start MongoDB (if not running)
mongod --dbpath "C:\data\db"

# 3. Start Flask server with MongoDB
python app_with_mongodb.py

# 4. Open browser
http://localhost:5000

# 5. See the button!
Click "📊 View History" in top-left corner
```

---

## ✅ Summary

**What changed in your files:**

1. ✅ Added CSS for `.history-btn` style
2. ✅ Added `<a href="mongodb_history_viewer.html" class="history-btn">📊 View History</a>` to header
3. ✅ Created `mongodb_history_viewer.html` (history viewer page)
4. ✅ Created `app_with_mongodb.py` (Flask server with MongoDB)

**What didn't change:**

- ❌ No changes to prediction form functionality
- ❌ No changes to ML model
- ❌ No changes to other features
- ❌ Original `app.py` still works (without MongoDB)

---

**Your prediction form now has a history button that connects to MongoDB! 🎉**

**Start using it:**
```bash
python app_with_mongodb.py
```

Then click "📊 View History" in the top-left corner! 
