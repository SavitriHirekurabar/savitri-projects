"""
Dynamic Marketing Pricing Model using Linear Regression
This module trains a machine learning model to predict optimal product prices
based on various market factors.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib
import json


def load_data(file_path):
    """Load and preprocess the dataset"""
    print("Loading dataset...")
    df = pd.read_csv(file_path)
    print(f"Dataset loaded: {len(df)} rows, {len(df.columns)} columns")
    return df


def preprocess_data(df):
    """
    Preprocess the data: encode categorical variables and prepare features
    """
    print("\nPreprocessing data...")
    
    # Create a copy to avoid modifying original data
    data = df.copy()
    
    # Encode categorical variables
    # Brand encoding
    brand_mapping = {'BrandA': 0, 'BrandB': 1, 'BrandC': 2, 'BrandD': 3}
    data['brand_encoded'] = data['brand'].map(brand_mapping)
    
    # Category encoding
    category_mapping = {'Electronics': 0, 'Home': 1, 'Beauty': 2, 'Clothing': 3}
    data['category_encoded'] = data['product_category'].map(category_mapping)
    
    # Promotion type encoding
    promotion_mapping = {'Sale': 0, 'Clearance': 1, 'Festival': 2}
    data['promotion_encoded'] = data['promotion_type'].map(promotion_mapping)
    
    # Season encoding
    season_mapping = {'Summer': 0, 'Winter': 1, 'Monsoon': 2, 'Festival': 3}
    data['season_encoded'] = data['season'].map(season_mapping)
    
    print("Data preprocessing completed")
    return data


def select_features(data):
    """
    Select relevant features for the model
    """
    feature_columns = [
        'base_price',
        'competitor_price',
        'cost_price',
        'stock_quantity',
        'daily_views',
        'daily_sales',
        'add_to_cart_count',
        'customer_rating',
        'discount_percentage',
        'advertising_spend',
        'brand_encoded',
        'category_encoded',
        'promotion_encoded',
        'season_encoded',
        'day_of_week',
        'demand_index',
        'price_elasticity'
    ]
    
    X = data[feature_columns]
    y = data['final_price']
    
    return X, y, feature_columns


def train_model(X, y):
    """
    Train the Linear Regression model
    """
    print("\n" + "="*60)
    print("TRAINING LINEAR REGRESSION MODEL")
    print("="*60)
    
    # Split data into training and testing sets (80-20 split)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\nTraining set size: {len(X_train)} samples")
    print(f"Testing set size: {len(X_test)} samples")
    
    # Create and train the model
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # Make predictions
    y_pred_train = model.predict(X_train)
    y_pred_test = model.predict(X_test)
    
    # Evaluate the model
    print("\n" + "-"*60)
    print("MODEL EVALUATION METRICS")
    print("-"*60)
    
    # Training metrics
    train_mse = mean_squared_error(y_train, y_pred_train)
    train_rmse = np.sqrt(train_mse)
    train_mae = mean_absolute_error(y_train, y_pred_train)
    train_r2 = r2_score(y_train, y_pred_train)
    
    print(f"\nTraining Performance:")
    print(f"  - Mean Squared Error (MSE): {train_mse:.2f}")
    print(f"  - Root Mean Squared Error (RMSE): {train_rmse:.2f}")
    print(f"  - Mean Absolute Error (MAE): {train_mae:.2f}")
    print(f"  - R² Score: {train_r2:.4f} ({train_r2*100:.2f}%)")
    
    # Testing metrics
    test_mse = mean_squared_error(y_test, y_pred_test)
    test_rmse = np.sqrt(test_mse)
    test_mae = mean_absolute_error(y_test, y_pred_test)
    test_r2 = r2_score(y_test, y_pred_test)
    
    print(f"\nTesting Performance:")
    print(f"  - Mean Squared Error (MSE): {test_mse:.2f}")
    print(f"  - Root Mean Squared Error (RMSE): {test_rmse:.2f}")
    print(f"  - Mean Absolute Error (MAE): {test_mae:.2f}")
    print(f"  - R² Score: {test_r2:.4f} ({test_r2*100:.2f}%)")
    
    # Feature importance (coefficients)
    print("\n" + "-"*60)
    print("FEATURE IMPORTANCE (Coefficients)")
    print("-"*60)
    feature_importance = pd.DataFrame({
        'Feature': X.columns,
        'Coefficient': model.coef_,
        'Impact': ['Positive' if coef > 0 else 'Negative' for coef in model.coef_]
    })
    feature_importance = feature_importance.sort_values('Coefficient', key=abs, ascending=False)
    print(feature_importance.to_string(index=False))
    
    print(f"\nIntercept (Bias): {model.intercept_:.2f}")
    
    return model, {
        'train_mse': train_mse,
        'train_rmse': train_rmse,
        'train_mae': train_mae,
        'train_r2': train_r2,
        'test_mse': test_mse,
        'test_rmse': test_rmse,
        'test_mae': test_mae,
        'test_r2': test_r2
    }


def save_model(model, model_path='pricing_model.pkl', metrics=None, feature_columns=None):
    """
    Save the trained model and metadata
    """
    print("\n" + "="*60)
    print("SAVING MODEL")
    print("="*60)
    
    # Save the model
    joblib.dump(model, model_path)
    print(f"✓ Model saved to {model_path}")
    
    # Save metadata
    metadata = {
        'feature_columns': feature_columns,
        'metrics': metrics,
        'model_type': 'Linear Regression',
        'training_date': pd.Timestamp.now().isoformat()
    }
    
    with open('model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2, default=str)
    print(f"✓ Model metadata saved to model_metadata.json")


def load_trained_model(model_path='pricing_model.pkl'):
    """
    Load a previously trained model
    """
    try:
        model = joblib.load(model_path)
        print(f"✓ Model loaded successfully from {model_path}")
        return model
    except FileNotFoundError:
        print(f"Error: Model file not found at {model_path}")
        return None


def predict_price(model, product_features, feature_columns):
    """
    Predict price for new product features
    
    Parameters:
    -----------
    model : Trained LinearRegression model
    product_features : dict containing product information
    feature_columns : list of feature names used in training
    
    Returns:
    --------
    float : Predicted final price
    """
    # Create feature vector in correct order
    features = []
    for col in feature_columns:
        if col in product_features:
            features.append(product_features[col])
        else:
            raise ValueError(f"Missing feature: {col}")
    
    # Reshape for prediction
    features_array = np.array(features).reshape(1, -1)
    
    # Make prediction
    predicted_price = model.predict(features_array)[0]
    
    return max(0, predicted_price)  # Ensure non-negative price


def main():
    """
    Main function to run the complete training pipeline
    """
    print("\n" + "="*60)
    print("DYNAMIC MARKETING PRICING MODEL")
    print("Machine Learning with Linear Regression")
    print("="*60)
    
    # Load data
    csv_file = 'marketing_product_dataset_500_rows.csv'
    df = load_data(csv_file)
    
    # Display dataset info
    print("\n" + "-"*60)
    print("DATASET OVERVIEW")
    print("-"*60)
    print(f"Total Records: {len(df)}")
    print(f"Total Features: {len(df.columns)}")
    print(f"\nFeatures: {', '.join(df.columns)}")
    print(f"\nTarget Variable: final_price")
    print(f"\nFirst 5 rows preview:")
    print(df.head())
    
    # Preprocess data
    data = preprocess_data(df)
    
    # Select features
    X, y, feature_columns = select_features(data)
    
    print("\n" + "-"*60)
    print("FEATURES USED FOR TRAINING")
    print("-"*60)
    for i, feature in enumerate(feature_columns, 1):
        print(f"{i}. {feature}")
    
    # Train model
    model, metrics = train_model(X, y)
    
    # Save model
    save_model(model, 'pricing_model.pkl', metrics, feature_columns)
    
    # Sample prediction
    print("\n" + "="*60)
    print("SAMPLE PREDICTION TEST")
    print("="*60)
    
    sample_product = {
        'base_price': 500.0,
        'competitor_price': 520.0,
        'cost_price': 350.0,
        'stock_quantity': 200,
        'daily_views': 3000,
        'daily_sales': 100,
        'add_to_cart_count': 150,
        'customer_rating': 4.5,
        'discount_percentage': 20,
        'advertising_spend': 2000.0,
        'brand_encoded': 1,  # BrandB
        'category_encoded': 0,  # Electronics
        'promotion_encoded': 2,  # Festival
        'season_encoded': 0,  # Summer
        'day_of_week': 3,
        'demand_index': 7,
        'price_elasticity': 1.5
    }
    
    predicted = predict_price(model, sample_product, feature_columns)
    print(f"\nSample Product Features:")
    print(f"  - Base Price: ${sample_product['base_price']}")
    print(f"  - Category: Electronics")
    print(f"  - Brand: BrandB")
    print(f"  - Promotion: Festival")
    print(f"\n💰 Predicted Optimal Price: ${predicted:.2f}")
    
    print("\n" + "="*60)
    print("TRAINING COMPLETED SUCCESSFULLY!")
    print("="*60)
    print("\nModel files created:")
    print("  1. pricing_model.pkl - Trained model")
    print("  2. model_metadata.json - Model metadata and metrics")
    print("\nYou can now use this model for price predictions!")


if __name__ == "__main__":
    main()
