"""
Automatic Price Prediction from Dataset
Runs predictions on your actual dataset automatically
"""

import pandas as pd
import numpy as np
from predict_price import PricePredictor


def main():
    print("="*80)
    print("DYNAMIC PRICING - ML MODEL PREDICTIONS")
    print("Using Linear Regression on Real Dataset")
    print("="*80)
    
    # Load the dataset
    csv_file = 'marketing_product_dataset_500_rows.csv'
    df = pd.read_csv(csv_file)
    
    # Initialize predictor
    predictor = PricePredictor()
    
    if predictor.model is None:
        print("\n❌ Error: Could not load the trained model!")
        print("   Please run: python pricing_model.py")
        return
    
    print(f"\n✓ Dataset loaded: {len(df)} products")
    print(f"✓ Model loaded with {predictor.metadata['metrics']['test_r2']*100:.2f}% accuracy\n")
    
    # Select 10 random samples
    samples = df.sample(n=10, random_state=42)
    
    results = []
    
    print("="*80)
    print("PRICE PREDICTIONS FOR SAMPLE PRODUCTS")
    print("="*80)
    
    for idx, row in samples.iterrows():
        print(f"\n{'-'*80}")
        print(f"Product ID: {row['product_id']}")
        print(f"Category: {row['product_category']:12} | Brand: {row['brand']:7} | Season: {row['season']}")
        print(f"Promotion: {row['promotion_type']} | Day: {row['day_of_week']}")
        
        # Prepare product data
        product_data = {
            'base_price': row['base_price'],
            'competitor_price': row['competitor_price'],
            'cost_price': row['cost_price'],
            'stock_quantity': row['stock_quantity'],
            'daily_views': row['daily_views'],
            'daily_sales': row['daily_sales'],
            'add_to_cart_count': row['add_to_cart_count'],
            'customer_rating': row['customer_rating'],
            'discount_percentage': row['discount_percentage'],
            'advertising_spend': row['advertising_spend'],
            'brand': row['brand'],
            'product_category': row['product_category'],
            'promotion_type': row['promotion_type'],
            'season': row['season'],
            'day_of_week': row['day_of_week'],
            'demand_index': row['demand_index'],
            'price_elasticity': row['price_elasticity']
        }
        
        # Make prediction
        result = predictor.predict(product_data)
        
        if 'error' in result:
            print(f"❌ Error: {result['error']}")
        else:
            predicted_price = result['predicted_price']
            actual_price = row['final_price']
            
            print(f"\nPricing Analysis:")
            print(f"   Current Final Price:     ${actual_price:>10.2f}")
            print(f"   ML Predicted Optimal:    ${predicted_price:>10.2f}")
            print(f"   Difference:              ${predicted_price - actual_price:>+10.2f} ({(predicted_price - actual_price) / actual_price * 100:+6.1f}%)")
            print(f"   Model Confidence:        {result['confidence']:.1f}%")
            
            # Recommendation
            diff = predicted_price - actual_price
            if abs(diff) <= 5:
                recommendation = "✅ Price is optimal"
            elif diff > 0:
                recommendation = f"📈 Increase price by ${diff:.2f}"
            else:
                recommendation = f"📉 Decrease price by ${abs(diff):.2f}"
            
            print(f"   Recommendation:          {recommendation}")
            
            # Store result
            results.append({
                'product_id': row['product_id'],
                'category': row['product_category'],
                'brand': row['brand'],
                'current_price': actual_price,
                'predicted_price': predicted_price,
                'difference': diff,
                'difference_percent': (diff / actual_price) * 100
            })
    
    # Summary
    print(f"\n{'='*80}")
    print("SUMMARY STATISTICS")
    print(f"{'='*80}")
    
    if results:
        results_df = pd.DataFrame(results)
        
        print(f"\nTotal Products Analyzed: {len(results)}")
        print(f"\nAverage Difference: ${results_df['difference'].mean():+.2f}")
        print(f"Average Absolute Deviation: ${results_df['difference'].abs().mean():.2f}")
        print(f"Average Percentage Deviation: {results_df['difference_percent'].abs().mean():.1f}%")
        
        # Count recommendations
        increase_count = len(results_df[results_df['difference'] > 5])
        decrease_count = len(results_df[results_df['difference'] < -5])
        optimal_count = len(results_df[abs(results_df['difference']) <= 5])
        
        print(f"\nRecommendations Breakdown:")
        print(f"   📈 Increase price: {increase_count} products ({increase_count/len(results)*100:.0f}%)")
        print(f"   📉 Decrease price: {decrease_count} products ({decrease_count/len(results)*100:.0f}%)")
        print(f"   ✅ Already optimal: {optimal_count} products ({optimal_count/len(results)*100:.0f}%)")
    
    print(f"\n{'='*80}")
    print("✅ Predictions completed successfully!")
    print(f"{'='*80}")
    
    # Show model info
    print(f"\nMODEL INFORMATION:")
    print(f"   Algorithm: Linear Regression")
    print(f"   Training Accuracy (R²): {predictor.metadata['metrics']['train_r2']*100:.2f}%")
    print(f"   Testing Accuracy (R²):  {predictor.metadata['metrics']['test_r2']*100:.2f}%")
    print(f"   RMSE: ${predictor.metadata['metrics']['test_rmse']:.2f}")
    print(f"   MAE: ${predictor.metadata['metrics']['test_mae']:.2f}")
    print(f"\n{'='*80}\n")


if __name__ == "__main__":
    main()
