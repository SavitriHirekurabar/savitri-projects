"""
Quick Test Script for Dynamic Pricing ML Model
This verifies that all components are working correctly
"""

import sys

def test_imports():
    """Test if all required packages are installed"""
    print("="*60)
    print("TEST 1: Checking Required Packages")
    print("="*60)
    
    try:
        import pandas as pd
        print("✓ pandas installed")
    except ImportError:
        print("✗ pandas NOT installed - Run: pip install pandas")
        return False
    
    try:
        import numpy as np
        print("✓ numpy installed")
    except ImportError:
        print("✗ numpy NOT installed - Run: pip install numpy")
        return False
    
    try:
        from sklearn.linear_model import LinearRegression
        print("✓ scikit-learn installed")
    except ImportError:
        print("✗ scikit-learn NOT installed - Run: pip install scikit-learn")
        return False
    
    try:
        import joblib
        print("✓ joblib installed")
    except ImportError:
        print("✗ joblib NOT installed - Run: pip install joblib")
        return False
    
    print("\n✅ All required packages are installed!\n")
    return True


def test_data_loading():
    """Test if dataset can be loaded"""
    print("="*60)
    print("TEST 2: Loading Dataset")
    print("="*60)
    
    try:
        import pandas as pd
        df = pd.read_csv('marketing_product_dataset_500_rows.csv')
        print(f"✓ Dataset loaded successfully")
        print(f"  - Rows: {len(df)}")
        print(f"  - Columns: {len(df.columns)}")
        print(f"\nFirst 3 rows preview:")
        print(df.head(3).to_string())
        print("\n✅ Dataset is ready!\n")
        return True, df
    except FileNotFoundError:
        print("✗ Dataset file NOT found!")
        print("  Make sure 'marketing_product_dataset_500_rows.csv' exists")
        return False, None
    except Exception as e:
        print(f"✗ Error loading dataset: {e}")
        return False, None


def test_model_exists():
    """Check if trained model exists"""
    print("="*60)
    print("TEST 3: Checking for Trained Model")
    print("="*60)
    
    import os
    if os.path.exists('pricing_model.pkl'):
        print("✓ Trained model found (pricing_model.pkl)")
        print("\n✅ Model is ready to use!\n")
        return True
    else:
        print("⚠ Model not found (pricing_model.pkl)")
        print("\nℹ You need to train the model first:")
        print("  Run: python pricing_model.py")
        print("\nThis will train the model and save it.\n")
        return False


def test_prediction():
    """Test making a prediction"""
    print("="*60)
    print("TEST 4: Testing Price Prediction")
    print("="*60)
    
    try:
        from predict_price import PricePredictor
        
        predictor = PricePredictor()
        
        if predictor.model is None:
            print("✗ Could not load model")
            print("  Please run: python pricing_model.py")
            return False
        
        # Sample product
        sample_product = {
            "base_price": 500.0,
            "competitor_price": 520.0,
            "cost_price": 350.0,
            "stock_quantity": 200,
            "daily_views": 3000,
            "daily_sales": 100,
            "add_to_cart_count": 150,
            "customer_rating": 4.5,
            "discount_percentage": 20,
            "advertising_spend": 2000.0,
            "brand": "BrandB",
            "product_category": "Electronics",
            "promotion_type": "Festival",
            "season": "Summer",
            "day_of_week": 3,
            "demand_index": 7,
            "price_elasticity": 1.5
        }
        
        result = predictor.predict(sample_product)
        
        if 'error' in result:
            print(f"✗ Prediction error: {result['error']}")
            return False
        
        print(f"✓ Prediction successful!")
        print(f"  - Predicted Price: ${result['predicted_price']}")
        print(f"  - Confidence: {result['confidence']}%")
        print(f"  - Model R² Score: {result['model_r2_score']}%")
        print("\n✅ Prediction system is working!\n")
        return True
        
    except Exception as e:
        print(f"✗ Error during prediction: {e}")
        print("  Make sure you've trained the model first")
        print("  Run: python pricing_model.py")
        return False


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("   DYNAMIC PRICING ML MODEL - SYSTEM CHECK")
    print("="*60 + "\n")
    
    results = {
        'imports': False,
        'data': False,
        'model': False,
        'prediction': False
    }
    
    # Test 1: Check imports
    results['imports'] = test_imports()
    if not results['imports']:
        print("\n" + "="*60)
        print("❌ INSTALLATION INCOMPLETE")
        print("="*60)
        print("\nPlease install required packages:")
        print("  pip install -r requirements.txt")
        print("\nOr run:")
        print("  pip install pandas numpy scikit-learn joblib")
        print("="*60 + "\n")
        return
    
    # Test 2: Check data
    results['data'], _ = test_data_loading()
    if not results['data']:
        print("\n" + "="*60)
        print("❌ DATASET NOT FOUND")
        print("="*60)
        print("\nMake sure 'marketing_product_dataset_500_rows.csv' exists")
        print("in the current directory.")
        print("="*60 + "\n")
        return
    
    # Test 3: Check model
    results['model'] = test_model_exists()
    
    # Test 4: Try prediction (only if model exists)
    if results['model']:
        results['prediction'] = test_prediction()
    
    # Summary
    print("="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"✓ Required Packages: {'INSTALLED' if results['imports'] else 'MISSING'}")
    print(f"✓ Dataset: {'LOADED' if results['data'] else 'NOT FOUND'}")
    print(f"✓ Trained Model: {'READY' if results['model'] else 'NEEDS TRAINING'}")
    print(f"✓ Predictions: {'WORKING' if results['prediction'] else 'MODEL REQUIRED'}")
    print("="*60)
    
    if all([results['imports'], results['data'], results['model'], results['prediction']]):
        print("\n🎉 ALL TESTS PASSED! System is fully operational!\n")
    elif results['imports'] and results['data']:
        print("\n⚙️  System is ready. Train the model to enable predictions.")
        print("\nNext step: python pricing_model.py\n")
    else:
        print("\n❌ Some components are missing. Please fix the issues above.\n")


if __name__ == "__main__":
    main()
