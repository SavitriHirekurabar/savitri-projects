# Dynamic Marketing Pricing Model - Machine Learning Guide

## Overview
This machine learning model uses **Linear Regression** to predict optimal product prices based on various market factors including competitor prices, demand, seasonality, and promotional activities.

## Features Used

The model considers **17 key features** for price prediction:

### Price-Related Features
1. **base_price** - Original product price
2. **competitor_price** - Competitor's price for similar product
3. **cost_price** - Product cost price

### Demand & Sales Features
4. **stock_quantity** - Available inventory
5. **daily_views** - Number of daily product page views
6. **daily_sales** - Number of daily sales
7. **add_to_cart_count** - Products added to cart daily
8. **demand_index** - Demand level (1-10)
9. **price_elasticity** - Price sensitivity coefficient

### Customer & Marketing Features
10. **customer_rating** - Average customer rating (1-5)
11. **discount_percentage** - Current discount %
12. **advertising_spend** - Marketing budget

### Categorical Features (Encoded)
13. **brand** - Brand name (BrandA, BrandB, BrandC, BrandD)
14. **product_category** - Category (Electronics, Home, Beauty, Clothing)
15. **promotion_type** - Promotion (Sale, Clearance, Festival)
16. **season** - Season (Summer, Winter, Monsoon, Festival)
17. **day_of_week** - Day (0-6, where 0 is Sunday)

## Installation

### Option 1: Using the Batch File (Windows - Recommended)
```bash
train_model.bat
```

### Option 2: Manual Installation
1. Install required packages:
```bash
pip install -r requirements.txt
```

2. Train the model:
```bash
python pricing_model.py
```

## Usage

### Training the Model
```bash
python pricing_model.py
```

This will:
- Load the dataset (500 product records)
- Preprocess and encode categorical variables
- Split data into training (80%) and testing (20%) sets
- Train the Linear Regression model
- Evaluate model performance
- Save the trained model to `pricing_model.pkl`
- Save metadata to `model_metadata.json`

### Making Predictions

#### Single Product Prediction
```python
from predict_price import PricePredictor

# Initialize predictor
predictor = PricePredictor()

# Define product
product = {
    "base_price": 500.0,
    "competitor_price": 520.0,
    "cost_price": 350.0,
    "stock_quantity": 200,
    "daily_views": 3000,
    "daily_sales": 100,
    "add_to_cart_count": 150,
    "customer_rating": 4.5,
    "discount_percentage": 20,
    "advertising_spend": 2000.0,
    "brand": "BrandB",
    "product_category": "Electronics",
    "promotion_type": "Festival",
    "season": "Summer",
    "day_of_week": 3,
    "demand_index": 7,
    "price_elasticity": 1.5
}

# Get prediction
result = predictor.predict(product)
print(f"Predicted Price: ${result['predicted_price']}")
print(f"Confidence: {result['confidence']}%")
```

#### Run Demo
```bash
python predict_price.py
```

## Model Performance Metrics

After training, you'll see:

### Training Metrics
- **R² Score**: Measures how well the model fits training data
- **RMSE**: Root Mean Squared Error (average prediction error)
- **MAE**: Mean Absolute Error (average absolute deviation)

### Testing Metrics
- **R² Score**: Model accuracy on unseen data
- **RMSE**: Generalization error
- **MAE**: Average absolute prediction error

### Feature Importance
The model shows which features have the most impact on pricing:
- **Positive coefficients**: Increase predicted price
- **Negative coefficients**: Decrease predicted price

## Output Files

After training, you'll get:

1. **pricing_model.pkl** - Trained Linear Regression model
2. **model_metadata.json** - Model information including:
   - Feature columns
   - Performance metrics
   - Training date
   - Model type

## Integration with Web Application

To integrate with your HTML/JavaScript frontend:

### Option 1: Flask API (Recommended)
Create `app.py`:
```python
from flask import Flask, request, jsonify
from predict_price import PricePredictor

app = Flask(__name__)
predictor = PricePredictor()

@app.route('/predict', methods=['POST'])
def predict():
    product_data = request.json
    result = predictor.predict(product_data)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
```

### Option 2: Direct JavaScript Integration
Use AJAX/Fetch to call Python backend from your HTML pages.

## Dataset Information

**Source**: `marketing_product_dataset_500_rows.csv`
- **Records**: 500 products
- **Features**: 20 columns
- **Target**: final_price

### Data Distribution
- **Categories**: Electronics, Home, Beauty, Clothing
- **Brands**: BrandA, BrandB, BrandC, BrandD
- **Promotions**: Sale, Clearance, Festival
- **Seasons**: Summer, Winter, Monsoon, Festival

## Algorithm Details

### Why Linear Regression?
1. **Interpretability**: Clear understanding of feature impact
2. **Speed**: Fast training and prediction
3. **Baseline**: Good starting point for regression problems
4. **Stability**: Consistent predictions with proper regularization

### Model Equation
```
final_price = β₀ + β₁(base_price) + β₂(competitor_price) + ... + β₁₇(price_elasticity)
```

Where:
- β₀ = Intercept (bias)
- β₁...β₁₇ = Coefficients (feature weights)

## Tips for Better Predictions

1. **Quality Data**: Ensure input values are realistic and accurate
2. **Feature Completeness**: Provide all 17 features for best results
3. **Regular Retraining**: Update model with new sales data periodically
4. **Monitor Performance**: Track actual vs predicted prices
5. **Domain Knowledge**: Adjust predictions based on business rules

## Troubleshooting

### Model Not Loading
- Ensure `pricing_model.pkl` exists in the same directory
- Run `python pricing_model.py` to train the model first

### Missing Feature Error
- Check that all required features are provided
- Verify feature names match exactly

### Low Accuracy
- Collect more training data
- Add more relevant features
- Try feature engineering
- Consider advanced algorithms (Random Forest, XGBoost)

## Next Steps

1. ✅ Train the model: `python pricing_model.py`
2. ✅ Test predictions: `python predict_price.py`
3. ✅ Integrate with web app
4. 📊 Monitor real-world performance
5. 🔄 Retrain with new data regularly

## Support

For questions or issues:
1. Check error messages carefully
2. Verify all dependencies are installed
3. Ensure dataset file exists
4. Review feature encoding mappings

---

**Created for**: DynamicPriceX - Dynamic Marketing Pricing System
**Algorithm**: Linear Regression
**Dataset**: 500 marketing products
**Last Updated**: 2026
