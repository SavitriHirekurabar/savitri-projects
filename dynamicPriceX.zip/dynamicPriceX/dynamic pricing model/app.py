from flask import Flask, request, jsonify, send_from_directory
from predict_price import PricePredictor
import os

app = Flask(__name__)

# Initialize the price predictor
predictor = None

try:
    predictor = PricePredictor('pricing_model.pkl')
    print("✓ ML Model loaded successfully")
except Exception as e:
    print(f"⚠ Warning: Could not load model - {e}")
    print("Please run 'python pricing_model.py' to train the model first")


@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'dynamic_pricing_v2.html')


@app.route('/api/predict', methods=['POST'])
def predict():
    """
    API endpoint for price prediction from frontend
    
    Expected JSON format from frontend form
    """
    if predictor is None:
        return jsonify({
            'error': 'Model not loaded. Please train the model first.',
            'instruction': 'Run: python pricing_model.py'
        }), 503
    
    try:
        product_data = request.get_json()
        
        if not product_data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Make prediction using trained model
        result = predictor.predict(product_data)
        
        if 'error' in result:
            return jsonify(result), 400
        
        # Add additional insights
        base_price = float(product_data.get('base_price', 0))
        predicted_price = result['predicted_price']
        
        if base_price > 0:
            difference = predicted_price - base_price
            diff_percent = (difference / base_price) * 100
            
            result['base_price'] = base_price
            result['difference'] = round(difference, 2)
            result['difference_percent'] = round(diff_percent, 1)
            
            # Generate recommendation
            if abs(difference) <= 5:
                result['recommendation'] = 'Price is optimal'
                result['action'] = 'keep'
            elif difference > 0:
                result['recommendation'] = f'Increase price by ${difference:.2f}'
                result['action'] = 'increase'
            else:
                result['recommendation'] = f'Decrease price by ${abs(difference):.2f}'
                result['action'] = 'decrease'
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict-bulk', methods=['POST'])
def predict_bulk():
    """
    API endpoint for bulk price predictions
    """
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    try:
        data = request.get_json()
        products = data.get('products', [])
        
        if not products:
            return jsonify({'error': 'No products provided'}), 400
        
        results = predictor.predict_bulk(products)
        return jsonify({'predictions': results})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/model-info', methods=['GET'])
def model_info():
    """Get model information and metrics"""
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    return jsonify({
        'model_type': predictor.metadata.get('model_type', 'Linear Regression'),
        'training_date': predictor.metadata.get('training_date', 'Unknown'),
        'features': predictor.feature_columns,
        'metrics': predictor.metadata.get('metrics', {}),
        'accuracy': round(predictor.metadata['metrics']['test_r2'] * 100, 2)
    })


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Dynamic Pricing API Server")
    print("="*60)
    print("\nStarting Flask server...")
    print("Access the app at: http://localhost:5000")
    print("\nAPI Endpoints:")
    print("  POST /api/predict      - Single price prediction")
    print("  POST /api/predict-bulk - Bulk price predictions")
    print("  GET  /api/model-info   - Model information")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
