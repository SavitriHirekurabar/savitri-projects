@echo off
cls
echo ================================================================================
echo                    DYNAMIC PRICING - ML MODEL PREDICTIONS
echo ================================================================================
echo.
echo Running Machine Learning Model on Real Dataset...
echo.

python run_predictions.py

echo.
echo ================================================================================
echo.
pause
