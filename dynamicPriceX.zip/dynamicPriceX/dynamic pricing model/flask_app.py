from flask import Flask, request, jsonify, send_from_directory
from predict_price import PricePredictor
import os

app = Flask(__name__)

# Initialize the price predictor
predictor = None

try:
    predictor = PricePredictor('pricing_model.pkl')
    print("✓ ML Model loaded successfully")
except Exception as e:
    print(f"⚠ Warning: Could not load model - {e}")
    print("Please run 'python pricing_model.py' to train the model first")


@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'dynamic_pricing_v2.html')


@app.route('/api/predict', methods=['POST'])
def predict():
    """
    API endpoint for price prediction
    
    Expected JSON format:
    {
        "base_price": 500.0,
        "competitor_price": 520.0,
        "cost_price": 350.0,
        "stock_quantity": 200,
        "daily_views": 3000,
        "daily_sales": 100,
        "add_to_cart_count": 150,
        "customer_rating": 4.5,
        "discount_percentage": 20,
        "advertising_spend": 2000.0,
        "brand": "BrandB",
        "product_category": "Electronics",
        "promotion_type": "Festival",
        "season": "Summer",
        "day_of_week": 3,
        "demand_index": 7,
        "price_elasticity": 1.5
    }
    """
    if predictor is None:
        return jsonify({
            'error': 'Model not loaded. Please train the model first.',
            'instruction': 'Run: python pricing_model.py'
        }), 503
    
    try:
        product_data = request.get_json()
        
        if not product_data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Make prediction
        result = predictor.predict(product_data)
        
        if 'error' in result:
            return jsonify(result), 400
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/predict-bulk', methods=['POST'])
def predict_bulk():
    """
    API endpoint for bulk price predictions
    
    Expected JSON format:
    {
        "products": [
            { product_data_1 },
            { product_data_2 },
            ...
        ]
    }
    """
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    try:
        data = request.get_json()
        products = data.get('products', [])
        
        if not products:
            return jsonify({'error': 'No products provided'}), 400
        
        results = predictor.predict_bulk(products)
        return jsonify({'predictions': results})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/model-info', methods=['GET'])
def model_info():
    """Get model information and metrics"""
    if predictor is None:
        return jsonify({'error': 'Model not loaded'}), 503
    
    return jsonify({
        'model_type': predictor.metadata.get('model_type', 'Linear Regression'),
        'training_date': predictor.metadata.get('training_date', 'Unknown'),
        'features': predictor.feature_columns,
        'metrics': predictor.metadata.get('metrics', {})
    })


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Dynamic Pricing API Server")
    print("="*60)
    print("\nStarting Flask server...")
    print("Access the app at: http://localhost:5000")
    print("\nAPI Endpoints:")
    print("  POST /api/predict      - Single price prediction")
    print("  POST /api/predict-bulk - Bulk price predictions")
    print("  GET  /api/model-info   - Model information")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
